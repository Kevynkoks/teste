#include <stdio.h>
#include <stdlio.h>
#include <ncurses.h>
#include "jogo.h"

int main(){

    char tecla;
    int campo [LIN][COL];

}